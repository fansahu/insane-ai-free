# Insane-AI Free
Made by Faizan Diwan

1. Is poore folder ko ek GitHub repo (branch: main) mein upload karo.
2. Actions tab -> "Build APK" khud chalega (ya Run workflow dabao).
3. 4-6 minute baad Releases mein `Insane-AI-Free.apk` milegi. Download karke install karo.
4. App kholo -> Settings -> free keys daalo (Gemini, Groq, OpenRouter, Cerebras, Mistral).
