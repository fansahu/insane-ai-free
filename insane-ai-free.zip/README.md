# Insane-AI Free
Made by Faizan Diwan

1. Is poore folder ko ek GitHub repo (branch: main) mein upload karo.
2. Actions tab -> "Build APK" khud chalega (ya Run workflow dabao).
3. 4-6 minute baad Releases mein `Insane-AI-Free.apk` milegi. Download karke install karo.
4. App kholo -> Settings -> free keys daalo (Gemini, Groq, OpenRouter, Cerebras, Mistral).

Providers: Gemini, Groq, OpenRouter, GitHub Models, Z.AI, Cohere, Cloudflare AI, LLM7, Mistral (sab free, billing/card nahi).
Modes: Chat, Image, Agent (search, wiki, read_url, calc, time).

Phase 3: Agent files + ZIP + GitHub APK build, agent model picker, agent resume, Compare mode.
Agent se APK: Settings -> GitHub token (repo + workflow) daalo, phir Agent mode mein bolo "X app banao, APK do, repo naam Y".
