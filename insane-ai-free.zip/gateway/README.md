# Master Gateway (ek key, kai free models)

Ye ek chhoti Cloudflare Worker hai (free plan, card nahi). Provider keys ek baar yahan daalo,
phir app (ya koi bhi device) ko sirf gateway ka URL aur ek MASTER token chahiye.
Ek provider ki limit khatam ho to gateway khud doosre pe chala jata hai.

## Setup (ek baar, ~5 minute)
1. dash.cloudflare.com pe Gmail se signup karo. Workers & Pages -> Create -> "Hello World" Worker -> Deploy.
2. Edit code kholo, saara code hata ke `worker.js` ka poora text paste karo, Deploy dabao.
3. Worker -> Settings -> Variables and Secrets -> Add (type: Secret):
   - `MASTER_TOKEN` = koi lamba random password (ye aapki master key hai)
   - jitni provider keys hain: `GROQ_KEY`, `GEMINI_KEY`, `OPENROUTER_KEY`, `GITHUB_KEY`, `ZAI_KEY`, `MISTRAL_KEY`, `COHERE_KEY`
     (ek provider ki kai keys ho to comma se alag karke daal sakte ho: `key1,key2`)
   - optional `ORDER` = `groq,gemini,openrouter` (kaun pehle try hoga)
4. Worker ka URL copy karo (https://....workers.dev).
5. App -> Settings -> Master Gateway: URL aur MASTER token daalo. Model sheet mein "Master" chuno.

## Model naam
- `auto` : saare providers, automatic failover
- `groq:llama-3.1-8b-instant` : sirf wahi provider aur wahi model

## Dhyan rakho
- Sirf free models chalte hain (paid model gateway se block hote hain).
- Quota har provider ka alag hai aur sab users ke liye saanjha. MASTER token kisi ko mat dena.
- Ek hi provider ke kai accounts bana ke limit todna unki terms ke khilaf hai. Isse bacho.
