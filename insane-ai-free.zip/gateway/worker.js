// Insane-AI Master Gateway - Cloudflare Worker (free plan).
// One MASTER_TOKEN in, many free models out, with automatic failover.
// Provider keys live here as Worker secrets (comma separated if you have several per provider).

const UPSTREAMS = [
  { id: 'groq',       base: 'https://api.groq.com/openai/v1',                          env: 'GROQ_KEY',       model: 'llama-3.3-70b-versatile' },
  { id: 'gemini',     base: 'https://generativelanguage.googleapis.com/v1beta/openai', env: 'GEMINI_KEY',     model: 'gemini-flash-latest' },
  { id: 'openrouter', base: 'https://openrouter.ai/api/v1',                            env: 'OPENROUTER_KEY', model: 'openrouter/free' },
  { id: 'github',     base: 'https://models.github.ai/inference',                      env: 'GITHUB_KEY',     model: 'openai/gpt-4o-mini' },
  { id: 'zai',        base: 'https://api.z.ai/api/paas/v4',                            env: 'ZAI_KEY',        model: 'glm-4.5-flash' },
  { id: 'mistral',    base: 'https://api.mistral.ai/v1',                               env: 'MISTRAL_KEY',    model: 'mistral-small-latest' },
  { id: 'cohere',     base: 'https://api.cohere.ai/compatibility/v1',                  env: 'COHERE_KEY',     model: 'command-a-03-2025' },
];

// Free-only guard: a paid model can never be reached through this gateway.
const FREE = {
  openrouter: m => /:free$/.test(m) || m === 'openrouter/free',
  gemini: m => /(flash|lite|gemma)/i.test(m) && !/(pro|image|tts|embed|imagen|veo|live|audio)/i.test(m),
  zai: m => /flash/i.test(m),
};

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization,content-type',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
};
const json = (o, status = 200, extra = {}) =>
  new Response(JSON.stringify(o), { status, headers: { 'content-type': 'application/json', ...CORS, ...extra } });

function safeEq(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
function keysOf(env, u) {
  const ks = String(env[u.env] || '').split(',').map(s => s.trim()).filter(Boolean);
  if (ks.length > 1) { const o = Math.floor(Math.random() * ks.length); return ks.slice(o).concat(ks.slice(0, o)); }
  return ks;
}
function ordered(env) {
  const pref = String(env.ORDER || '').split(',').map(s => s.trim()).filter(Boolean);
  if (!pref.length) return UPSTREAMS;
  return pref.map(id => UPSTREAMS.find(u => u.id === id)).filter(Boolean)
    .concat(UPSTREAMS.filter(u => !pref.includes(u.id)));
}
// "auto" -> every provider that has a key; "groq:llama-3.1-8b-instant" -> only that provider.
function plan(model, env) {
  const m = String(model || 'auto');
  const x = m.match(/^([a-z0-9]+):(.+)$/);
  const up = x && UPSTREAMS.find(u => u.id === x[1]);
  if (up) return [{ u: up, model: x[2] }];
  return ordered(env).map(u => ({ u, model: u.model }));
}

export default {
  async fetch(req, env) {
    if (req.method === 'OPTIONS') return new Response(null, { headers: CORS });
    const auth = (req.headers.get('authorization') || '').replace(/^Bearer\s+/i, '');
    if (!env.MASTER_TOKEN || !safeEq(auth, env.MASTER_TOKEN)) return json({ error: { message: 'unauthorized' } }, 401);
    const path = new URL(req.url).pathname.replace(/\/+$/, '');

    if (req.method === 'GET' && /\/models$/.test(path)) {
      const ids = ['auto'].concat(UPSTREAMS.filter(u => keysOf(env, u).length).map(u => u.id + ':' + u.model));
      return json({ object: 'list', data: ids.map(id => ({ id, object: 'model' })) });
    }
    if (req.method === 'POST' && /\/chat\/completions$/.test(path)) {
      let body;
      try { body = await req.json(); } catch (e) { return json({ error: { message: 'bad json' } }, 400); }
      const errors = [];
      for (const step of plan(body.model, env)) {
        const { u, model } = step;
        if (FREE[u.id] && !FREE[u.id](model)) { errors.push(u.id + ': model is not free'); continue; }
        for (const key of keysOf(env, u)) {
          try {
            const r = await fetch(u.base + '/chat/completions', {
              method: 'POST',
              headers: { 'content-type': 'application/json', authorization: 'Bearer ' + key },
              body: JSON.stringify({ ...body, model, stream: false }),
            });
            if (r.ok) return new Response(r.body, { status: 200, headers: { 'content-type': 'application/json', 'x-upstream': u.id, 'x-upstream-model': model, ...CORS } });
            errors.push(u.id + ': ' + r.status);
          } catch (e) { errors.push(u.id + ': network'); }
        }
      }
      return json({ error: { message: errors.length ? 'all providers failed: ' + errors.join(', ') : 'no provider keys configured' } }, 502);
    }
    return json({ error: { message: 'not found' } }, 404);
  },
};
