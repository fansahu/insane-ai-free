// Runs automatically after "npx cap sync" (npm hook: capacitor:sync:after).
// Adds mic permission, speech-service query, "Share to app" intent and the share bridge.
const fs = require('fs'), path = require('path');
const cfg = JSON.parse(fs.readFileSync('capacitor.config.json', 'utf8'));
const pkg = cfg.appId;
const man = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(man)) { console.log('patch-android: no android project, skipped'); process.exit(0); }
let m = fs.readFileSync(man, 'utf8');
if (!m.includes('android.permission.RECORD_AUDIO')) {
  m = m.replace('<application', '<uses-permission android:name="android.permission.RECORD_AUDIO" />\n    <application');
}
if (!m.includes('android.speech.RecognitionService')) {
  m = m.replace('<application', '<queries><intent><action android:name="android.speech.RecognitionService" /></intent></queries>\n    <application');
}
if (!m.includes('android.intent.action.SEND')) {
  m = m.replace('</activity>', '    <intent-filter>\n                <action android:name="android.intent.action.SEND" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <data android:mimeType="text/plain" />\n            </intent-filter>\n        </activity>');
}
fs.writeFileSync(man, m);
const dir = path.join('android/app/src/main/java', ...pkg.split('.'));
fs.mkdirSync(dir, { recursive: true });
const java = `package ${pkg};

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import org.json.JSONObject;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    handleShare(getIntent());
  }

  @Override
  protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    handleShare(intent);
  }

  private void handleShare(Intent intent) {
    if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
    String text = intent.getStringExtra(Intent.EXTRA_TEXT);
    if (text == null) return;
    final String js = "window.__shared=" + JSONObject.quote(text) + ";if(window.onShared)window.onShared();";
    final WebView w = getBridge().getWebView();
    int[] delays = {800, 2000, 4000};
    for (int d : delays) {
      w.postDelayed(new Runnable() {
        @Override
        public void run() {
          w.evaluateJavascript(js, null);
        }
      }, d);
    }
  }
}
`;
fs.writeFileSync(path.join(dir, 'MainActivity.java'), java);
console.log('patch-android: done for ' + pkg);
